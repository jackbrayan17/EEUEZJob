import os
import sys


# sys.path.insert(0, os.path.dirname(__file__))


# def application(environ, start_response):
#     start_response('200 OK', [('Content-Type', 'text/plain')])
#     message = 'It works!\n'
#     version = 'Python %s\n' % sys.version.split()[0]
#     response = '\n'.join([message, version])
#     return [response.encode()]
project_path = '/home/ch686a7f851a0fa/eeuez_job'
if project_path not in sys.path:
    sys.path.append(project_path)
from eeuezjob.wsgi import application
