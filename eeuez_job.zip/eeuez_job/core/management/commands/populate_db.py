from django.core.management.base import BaseCommand
from django.contrib.auth.models import User
from django.utils import timezone
from core.models import Category, RecruiterProfile, JobOffer
import random

class Command(BaseCommand):
    help = 'Populates the database with 7 job offers per sector'

    def handle(self, *args, **kwargs):
        # Password for all users
        password = 'brayan8003'

        # Cameroon cities for job locations
        cities = ['Yaoundé', 'Douala', 'Bamenda', 'Buea', 'Garoua', 'Maroua', 'Ngaoundéré']

        # Job offer templates per sector
        job_templates = {
            "Agriculture": [
                {"title": "Agronomist for Sustainable Cocoa Farming", "description": "Join our cooperative in {city} to enhance cocoa yield through sustainable practices. Responsibilities include soil analysis, crop rotation planning, and farmer training.", "experience": "3+ years", "salary": "600,000 FCFA/month"},
                {"title": "Livestock Manager", "description": "Oversee poultry and cattle farming operations in {city}. Manage feed supply, health checks, and production schedules to ensure quality output.", "experience": "5+ years", "salary": "750,000 FCFA/month"},
                {"title": "Agribusiness Marketing Specialist", "description": "Develop marketing strategies for agricultural products in {city}. Work with local farmers to promote palm oil and coffee in national markets.", "experience": "2+ years", "salary": "500,000 FCFA/month"},
                {"title": "Irrigation Systems Engineer", "description": "Design and maintain irrigation systems for rice fields in {city}. Knowledge of drip irrigation and water management is essential.", "experience": "4+ years", "salary": "700,000 FCFA/month"},
                {"title": "Organic Farming Consultant", "description": "Provide expertise on organic farming techniques in {city}. Train farmers on pesticide-free methods and certification processes.", "experience": "3+ years", "salary": "550,000 FCFA/month"},
                {"title": "Agricultural Extension Officer", "description": "Support rural farmers in {city} with modern farming techniques. Conduct workshops and field visits to boost productivity.", "experience": "2+ years", "salary": "450,000 FCFA/month"},
                {"title": "Horticulture Supervisor", "description": "Manage vegetable and fruit cultivation projects in {city}. Ensure high-quality produce for local and export markets.", "experience": "4+ years", "salary": "650,000 FCFA/month"},
            ],
            "Électronique": [
                {"title": "Electronics Repair Technician", "description": "Repair consumer electronics like smartphones and TVs in our {city} service center. Strong troubleshooting skills required.", "experience": "2+ years", "salary": "400,000 FCFA/month"},
                {"title": "Embedded Systems Engineer", "description": "Develop firmware for IoT devices in {city}. Work on smart home systems for local businesses.", "experience": "3+ years", "salary": "800,000 FCFA/month"},
                {"title": "Solar Panel Installation Expert", "description": "Install and maintain solar panels for households in {city}. Knowledge of photovoltaic systems is key.", "experience": "3+ years", "salary": "600,000 FCFA/month"},
                {"title": "Circuit Design Engineer", "description": "Design electronic circuits for industrial equipment in {city}. Collaborate with manufacturers for production.", "experience": "4+ years", "salary": "750,000 FCFA/month"},
                {"title": "Electronics Sales Manager", "description": "Lead sales of electronic components in {city}. Build relationships with retailers and distributors.", "experience": "3+ years", "salary": "550,000 FCFA/month"},
                {"title": "Automation Technician", "description": "Maintain automated systems for factories in {city}. Experience with PLC programming is a plus.", "experience": "3+ years", "salary": "650,000 FCFA/month"},
                {"title": "Quality Control Engineer", "description": "Ensure quality standards for electronics manufacturing in {city}. Conduct tests and inspections.", "experience": "2+ years", "salary": "500,000 FCFA/month"},
            ],
            "Informatique": [
                {"title": "Full Stack Developer", "description": "Build web applications for startups in {city}. Proficiency in Django and React is required.", "experience": "3+ years", "salary": "900,000 FCFA/month"},
                {"title": "Cybersecurity Analyst", "description": "Protect corporate networks in {city} from cyber threats. Conduct penetration testing and audits.", "experience": "4+ years", "salary": "1,000,000 FCFA/month"},
                {"title": "Mobile App Developer", "description": "Develop Android and iOS apps for fintech companies in {city}. Experience with Flutter is a plus.", "experience": "3+ years", "salary": "850,000 FCFA/month"},
                {"title": "Database Administrator", "description": "Manage MySQL and PostgreSQL databases for businesses in {city}. Ensure data integrity and performance.", "experience": "3+ years", "salary": "700,000 FCFA/month"},
                {"title": "IT Support Specialist", "description": "Provide technical support for office systems in {city}. Troubleshoot hardware and software issues.", "experience": "2+ years", "salary": "450,000 FCFA/month"},
                {"title": "AI Engineer", "description": "Develop machine learning models for local startups in {city}. Experience with TensorFlow is required.", "experience": "4+ years", "salary": "1,200,000 FCFA/month"},
                {"title": "Cloud Architect", "description": "Design cloud infrastructure for enterprises in {city}. Expertise in AWS or Azure is essential.", "experience": "5+ years", "salary": "1,100,000 FCFA/month"},
            ],
            "Droit": [
                {"title": "Corporate Lawyer", "description": "Provide legal counsel for businesses in {city}. Draft contracts and ensure compliance with OHADA laws.", "experience": "5+ years", "salary": "1,200,000 FCFA/month"},
                {"title": "Human Rights Advocate", "description": "Work with NGOs in {city} to promote human rights. Handle cases related to labor and gender equality.", "experience": "3+ years", "salary": "800,000 FCFA/month"},
                {"title": "Tax Law Consultant", "description": "Advise companies in {city} on tax regulations. Optimize tax strategies for local businesses.", "experience": "4+ years", "salary": "900,000 FCFA/month"},
                {"title": "Litigation Attorney", "description": "Represent clients in court cases in {city}. Specialize in commercial and civil disputes.", "experience": "5+ years", "salary": "1,000,000 FCFA/month"},
                {"title": "Legal Advisor for Startups", "description": "Support tech startups in {city} with intellectual property and regulatory compliance.", "experience": "3+ years", "salary": "750,000 FCFA/month"},
                {"title": "Notary Public", "description": "Authenticate legal documents and contracts in {city}. Ensure proper documentation for real estate deals.", "experience": "4+ years", "salary": "850,000 FCFA/month"},
                {"title": "Compliance Officer", "description": "Ensure businesses in {city} adhere to local and international regulations.", "experience": "3+ years", "salary": "700,000 FCFA/month"},
            ],
            "Marketing": [
                {"title": "Digital Marketing Manager", "description": "Lead online campaigns for brands in {city}. Expertise in SEO and social media advertising.", "experience": "3+ years", "salary": "700,000 FCFA/month"},
                {"title": "Brand Strategist", "description": "Develop brand identities for local businesses in {city}. Create compelling marketing campaigns.", "experience": "4+ years", "salary": "800,000 FCFA/month"},
                {"title": "Market Research Analyst", "description": "Conduct consumer research for products in {city}. Analyze trends to guide marketing strategies.", "experience": "2+ years", "salary": "550,000 FCFA/month"},
                {"title": "Social Media Coordinator", "description": "Manage social media accounts for companies in {city}. Create engaging content for TikTok and Instagram.", "experience": "2+ years", "salary": "450,000 FCFA/month"},
                {"title": "Content Marketing Specialist", "description": "Write blogs and promotional content for businesses in {city}. Knowledge of local markets is key.", "experience": "3+ years", "salary": "600,000 FCFA/month"},
                {"title": "Event Marketing Manager", "description": "Organize promotional events in {city}. Coordinate logistics and sponsorships.", "experience": "3+ years", "salary": "650,000 FCFA/month"},
                {"title": "Public Relations Officer", "description": "Manage media relations for organizations in {city}. Build positive public image.", "experience": "3+ years", "salary": "600,000 FCFA/month"},
            ],
            "Santé": [
                {"title": "General Practitioner", "description": "Provide primary care services in a {city} clinic. Diagnose and treat common ailments.", "experience": "3+ years", "salary": "900,000 FCFA/month"},
                {"title": "Public Health Officer", "description": "Lead vaccination campaigns in {city}. Work with NGOs to improve community health.", "experience": "4+ years", "salary": "800,000 FCFA/month"},
                {"title": "Nurse Practitioner", "description": "Assist doctors in a {city} hospital. Provide patient care and administer medications.", "experience": "2+ years", "salary": "500,000 FCFA/month"},
                {"title": "Pharmacist", "description": "Manage pharmacy operations in {city}. Ensure proper dispensing of medications.", "experience": "3+ years", "salary": "700,000 FCFA/month"},
                {"title": "Medical Laboratory Technician", "description": "Conduct diagnostic tests in a {city} lab. Analyze blood and tissue samples.", "experience": "2+ years", "salary": "550,000 FCFA/month"},
                {"title": "Health Educator", "description": "Educate communities in {city} on disease prevention. Focus on malaria and HIV awareness.", "experience": "2+ years", "salary": "450,000 FCFA/month"},
                {"title": "Surgical Assistant", "description": "Assist surgeons during operations in {city} hospitals. Ensure sterile conditions.", "experience": "3+ years", "salary": "650,000 FCFA/month"},
            ],
            "Éducation": [
                {"title": "Secondary School Teacher", "description": "Teach mathematics and science in a {city} high school. Prepare students for GCE exams.", "experience": "2+ years", "salary": "400,000 FCFA/month"},
                {"title": "University Lecturer", "description": "Teach undergraduate courses in {city}. Specialize in history or literature.", "experience": "5+ years", "salary": "800,000 FCFA/month"},
                {"title": "Educational Consultant", "description": "Advise schools in {city} on curriculum development. Improve teaching methodologies.", "experience": "4+ years", "salary": "700,000 FCFA/month"},
                {"title": "Special Needs Educator", "description": "Support students with disabilities in {city}. Develop individualized education plans.", "experience": "3+ years", "salary": "550,000 FCFA/month"},
                {"title": "School Administrator", "description": "Manage operations of a private school in {city}. Oversee staff and budgets.", "experience": "5+ years", "salary": "750,000 FCFA/month"},
                {"title": "English Language Trainer", "description": "Teach English to adults in {city}. Focus on conversational and business English.", "experience": "2+ years", "salary": "450,000 FCFA/month"},
                {"title": "STEM Program Coordinator", "description": "Develop STEM programs for schools in {city}. Promote science and tech education.", "experience": "3+ years", "salary": "600,000 FCFA/month"},
            ],
            "Construction": [
                {"title": "Civil Engineer", "description": "Design infrastructure projects like bridges in {city}. Ensure compliance with safety standards.", "experience": "4+ years", "salary": "900,000 FCFA/month"},
                {"title": "Construction Site Manager", "description": "Oversee building projects in {city}. Coordinate workers and ensure timely completion.", "experience": "5+ years", "salary": "800,000 FCFA/month"},
                {"title": "Quantity Surveyor", "description": "Estimate costs for construction projects in {city}. Prepare detailed budgets.", "experience": "3+ years", "salary": "650,000 FCFA/month"},
                {"title": "Mason", "description": "Build structures using bricks and concrete in {city}. Work on residential projects.", "experience": "2+ years", "salary": "400,000 FCFA/month"},
                {"title": "Structural Engineer", "description": "Analyze building designs for safety in {city}. Focus on earthquake-resistant structures.", "experience": "4+ years", "salary": "850,000 FCFA/month"},
                {"title": "Construction Safety Officer", "description": "Ensure safety protocols on sites in {city}. Conduct risk assessments.", "experience": "3+ years", "salary": "550,000 FCFA/month"},
                {"title": "Interior Finishing Specialist", "description": "Handle tiling and painting for buildings in {city}. Ensure high-quality finishes.", "experience": "2+ years", "salary": "450,000 FCFA/month"},
            ],
            "Finance": [
                {"title": "Financial Analyst", "description": "Analyze investment opportunities for firms in {city}. Prepare financial reports.", "experience": "3+ years", "salary": "800,000 FCFA/month"},
                {"title": "Bank Branch Manager", "description": "Manage operations of a bank branch in {city}. Oversee customer service and loans.", "experience": "5+ years", "salary": "1,000,000 FCFA/month"},
                {"title": "Accountant", "description": "Handle financial records for businesses in {city}. Ensure tax compliance.", "experience": "3+ years", "salary": "600,000 FCFA/month"},
                {"title": "Microfinance Officer", "description": "Support small businesses in {city} with microloans. Assess creditworthiness.", "experience": "2+ years", "salary": "450,000 FCFA/month"},
                {"title": "Investment Advisor", "description": "Guide clients in {city} on stock and bond investments. Develop portfolios.", "experience": "4+ years", "salary": "850,000 FCFA/month"},
                {"title": "Risk Analyst", "description": "Evaluate financial risks for companies in {city}. Recommend mitigation strategies.", "experience": "3+ years", "salary": "700,000 FCFA/month"},
                {"title": "Credit Controller", "description": "Manage credit policies for firms in {city}. Ensure timely debt recovery.", "experience": "3+ years", "salary": "550,000 FCFA/month"},
            ],
            "Ressources humaines": [
                {"title": "HR Manager", "description": "Oversee recruitment and employee welfare in {city}. Develop HR policies.", "experience": "5+ years", "salary": "800,000 FCFA/month"},
                {"title": "Talent Acquisition Specialist", "description": "Recruit top talent for companies in {city}. Conduct interviews and screenings.", "experience": "3+ years", "salary": "600,000 FCFA/month"},
                {"title": "Payroll Administrator", "description": "Manage employee salaries and benefits in {city}. Ensure accurate payroll processing.", "experience": "2+ years", "salary": "500,000 FCFA/month"},
                {"title": "Training Coordinator", "description": "Organize employee training programs in {city}. Focus on skill development.", "experience": "3+ years", "salary": "550,000 FCFA/month"},
                {"title": "Employee Relations Officer", "description": "Handle workplace disputes in {city}. Promote a positive work environment.", "experience": "3+ years", "salary": "600,000 FCFA/month"},
                {"title": "HR Consultant", "description": "Advise businesses in {city} on HR strategies. Optimize workforce planning.", "experience": "4+ years", "salary": "700,000 FCFA/month"},
                {"title": "Performance Analyst", "description": "Evaluate employee performance in {city}. Design appraisal systems.", "experience": "3+ years", "salary": "550,000 FCFA/month"},
            ],
            "Vente": [
                {"title": "Sales Manager", "description": "Lead sales teams for retail stores in {city}. Achieve revenue targets.", "experience": "4+ years", "salary": "700,000 FCFA/month"},
                {"title": "Retail Sales Associate", "description": "Assist customers in {city} stores. Promote products and handle transactions.", "experience": "1+ year", "salary": "300,000 FCFA/month"},
                {"title": "B2B Sales Executive", "description": "Secure contracts with businesses in {city}. Focus on wholesale products.", "experience": "3+ years", "salary": "600,000 FCFA/month"},
                {"title": "Sales Analyst", "description": "Analyze sales data for companies in {city}. Identify growth opportunities.", "experience": "2+ years", "salary": "500,000 FCFA/month"},
                {"title": "Customer Success Manager", "description": "Ensure client satisfaction for services in {city}. Build long-term relationships.", "experience": "3+ years", "salary": "550,000 FCFA/month"},
                {"title": "Field Sales Representative", "description": "Promote products door-to-door in {city}. Focus on consumer goods.", "experience": "2+ years", "salary": "400,000 FCFA/month"},
                {"title": "E-commerce Sales Specialist", "description": "Manage online sales platforms in {city}. Optimize product listings.", "experience": "2+ years", "salary": "450,000 FCFA/month"},
            ],
            "Logistique": [
                {"title": "Logistics Manager", "description": "Oversee supply chain operations in {city}. Ensure timely delivery of goods.", "experience": "5+ years", "salary": "800,000 FCFA/month"},
                {"title": "Warehouse Supervisor", "description": "Manage inventory in a {city} warehouse. Coordinate stock and shipments.", "experience": "3+ years", "salary": "550,000 FCFA/month"},
                {"title": "Transport Coordinator", "description": "Plan delivery routes for goods in {city}. Optimize transport efficiency.", "experience": "2+ years", "salary": "450,000 FCFA/month"},
                {"title": "Supply Chain Analyst", "description": "Analyze logistics data in {city}. Recommend cost-saving strategies.", "experience": "3+ years", "salary": "600,000 FCFA/month"},
                {"title": "Freight Forwarder", "description": "Handle international shipments from {city}. Manage customs documentation.", "experience": "3+ years", "salary": "650,000 FCFA/month"},
                {"title": "Inventory Controller", "description": "Track stock levels in {city} warehouses. Prevent overstocking issues.", "experience": "2+ years", "salary": "500,000 FCFA/month"},
                {"title": "Logistics Planner", "description": "Plan logistics operations for businesses in {city}. Ensure smooth supply chains.", "experience": "3+ years", "salary": "550,000 FCFA/month"},
            ],
            "Télécommunications": [
                {"title": "Network Engineer", "description": "Maintain telecom networks in {city}. Ensure reliable mobile and internet services.", "experience": "4+ years", "salary": "900,000 FCFA/month"},
                {"title": "Telecom Sales Manager", "description": "Promote telecom services in {city}. Build client relationships for mobile plans.", "experience": "3+ years", "salary": "650,000 FCFA/month"},
                {"title": "Field Technician", "description": "Install and repair telecom equipment in {city}. Troubleshoot network issues.", "experience": "2+ years", "salary": "450,000 FCFA/month"},
                {"title": "RF Engineer", "description": "Optimize radio frequency networks in {city}. Improve signal coverage.", "experience": "4+ years", "salary": "800,000 FCFA/month"},
                {"title": "Customer Support Agent", "description": "Handle telecom customer queries in {city}. Resolve billing and service issues.", "experience": "1+ year", "salary": "350,000 FCFA/month"},
                {"title": "Network Security Specialist", "description": "Protect telecom systems in {city} from cyber threats. Implement firewalls.", "experience": "3+ years", "salary": "750,000 FCFA/month"},
                {"title": "Telecom Project Manager", "description": "Lead telecom infrastructure projects in {city}. Ensure timely deployment.", "experience": "5+ years", "salary": "900,000 FCFA/month"},
            ],
            "Énergie": [
                {"title": "Renewable Energy Engineer", "description": "Design solar and wind energy systems in {city}. Promote green energy solutions.", "experience": "4+ years", "salary": "850,000 FCFA/month"},
                {"title": "Power Plant Operator", "description": "Operate hydroelectric plants in {city}. Ensure consistent energy supply.", "experience": "3+ years", "salary": "600,000 FCFA/month"},
                {"title": "Energy Auditor", "description": "Conduct energy audits for buildings in {city}. Recommend efficiency measures.", "experience": "3+ years", "salary": "550,000 FCFA/month"},
                {"title": "Electrical Engineer", "description": "Maintain power distribution systems in {city}. Ensure grid reliability.", "experience": "4+ years", "salary": "800,000 FCFA/month"},
                {"title": "Energy Sales Manager", "description": "Promote energy solutions to businesses in {city}. Focus on solar products.", "experience": "3+ years", "salary": "650,000 FCFA/month"},
                {"title": "Maintenance Technician", "description": "Repair energy equipment in {city}. Ensure uptime for power systems.", "experience": "2+ years", "salary": "450,000 FCFA/month"},
                {"title": "Energy Policy Analyst", "description": "Advise on energy regulations in {city}. Support sustainable energy policies.", "experience": "3+ years", "salary": "700,000 FCFA/month"},
            ],
            "Tourisme": [
                {"title": "Tour Guide", "description": "Lead cultural tours in {city}. Showcase historical and natural attractions.", "experience": "2+ years", "salary": "400,000 FCFA/month"},
                {"title": "Travel Agency Manager", "description": "Manage travel packages for tourists in {city}. Coordinate with hotels and airlines.", "experience": "4+ years", "salary": "650,000 FCFA/month"},
                {"title": "Hospitality Manager", "description": "Oversee hotel operations in {city}. Ensure guest satisfaction and quality service.", "experience": "5+ years", "salary": "800,000 FCFA/month"},
                {"title": "Tourism Marketing Specialist", "description": "Promote tourism destinations in {city}. Create campaigns for local attractions.", "experience": "3+ years", "salary": "550,000 FCFA/month"},
                {"title": "Event Planner for Tourism", "description": "Organize cultural festivals in {city}. Coordinate logistics and vendors.", "experience": "3+ years", "salary": "500,000 FCFA/month"},
                {"title": "Eco-Tourism Coordinator", "description": "Develop sustainable tourism projects in {city}. Focus on wildlife conservation.", "experience": "3+ years", "salary": "600,000 FCFA/month"},
                {"title": "Customer Service Agent", "description": "Assist tourists with bookings in {city}. Provide travel advice and support.", "experience": "1+ year", "salary": "350,000 FCFA/month"},
            ],
            "Mode": [
                {"title": "Fashion Designer", "description": "Create unique clothing lines in {city}. Blend traditional and modern Cameroonian styles.", "experience": "3+ years", "salary": "600,000 FCFA/month"},
                {"title": "Textile Production Manager", "description": "Oversee fabric production in {city}. Ensure quality for fashion brands.", "experience": "4+ years", "salary": "700,000 FCFA/month"},
                {"title": "Fashion Retail Manager", "description": "Manage clothing stores in {city}. Drive sales and manage inventory.", "experience": "3+ years", "salary": "550,000 FCFA/month"},
                {"title": "Pattern Maker", "description": "Create patterns for garments in {city}. Work with designers for production.", "experience": "2+ years", "salary": "450,000 FCFA/month"},
                {"title": "Fashion Marketing Specialist", "description": "Promote fashion brands in {city}. Develop social media campaigns.", "experience": "3+ years", "salary": "500,000 FCFA/month"},
                {"title": "Tailor", "description": "Sew custom garments in {city}. Specialize in traditional attire like toghu.", "experience": "2+ years", "salary": "400,000 FCFA/month"},
                {"title": "Fashion Show Coordinator", "description": "Organize fashion events in {city}. Manage models and logistics.", "experience": "3+ years", "salary": "550,000 FCFA/month"},
            ],
            "Artisanat": [
                {"title": "Wood Carver", "description": "Create traditional wooden sculptures in {city}. Work with local artisans.", "experience": "2+ years", "salary": "400,000 FCFA/month"},
                {"title": "Pottery Artisan", "description": "Craft pottery items in {city}. Supply markets with decorative ceramics.", "experience": "2+ years", "salary": "350,000 FCFA/month"},
                {"title": "Basket Weaver", "description": "Produce handmade baskets in {city}. Use traditional techniques for quality.", "experience": "1+ year", "salary": "300,000 FCFA/month"},
                {"title": "Artisan Workshop Manager", "description": "Oversee craft production in {city}. Coordinate artisan teams and sales.", "experience": "3+ years", "salary": "500,000 FCFA/month"},
                {"title": "Jewelry Maker", "description": "Design handmade jewelry in {city}. Use local materials like beads and bronze.", "experience": "2+ years", "salary": "400,000 FCFA/month"},
                {"title": "Craft Marketing Specialist", "description": "Promote artisan products in {city}. Develop export markets.", "experience": "3+ years", "salary": "450,000 FCFA/month"},
                {"title": "Leatherworker", "description": "Create leather goods like bags in {city}. Focus on quality craftsmanship.", "experience": "2+ years", "salary": "400,000 FCFA/month"},
            ],
            "Médias": [
                {"title": "Journalist", "description": "Cover local news in {city}. Write articles for newspapers and online platforms.", "experience": "2+ years", "salary": "450,000 FCFA/month"},
                {"title": "Video Editor", "description": "Edit content for TV stations in {city}. Work on news and entertainment videos.", "experience": "3+ years", "salary": "550,000 FCFA/month"},
                {"title": "Radio Host", "description": "Host radio shows in {city}. Engage audiences with cultural programs.", "experience": "2+ years", "salary": "400,000 FCFA/month"},
                {"title": "Media Producer", "description": "Produce TV and radio content in {city}. Manage production schedules.", "experience": "4+ years", "salary": "700,000 FCFA/month"},
                {"title": "Social Media Manager", "description": "Manage media company accounts in {city}. Create viral content.", "experience": "2+ years", "salary": "500,000 FCFA/month"},
                {"title": "Photographer", "description": "Capture events and portraits in {city}. Work with media outlets.", "experience": "2+ years", "salary": "450,000 FCFA/month"},
                {"title": "Content Writer", "description": "Write scripts and articles for media in {city}. Focus on local stories.", "experience": "2+ years", "salary": "400,000 FCFA/month"},
            ],
            "Recherche": [
                {"title": "Research Scientist", "description": "Conduct agricultural research in {city}. Focus on crop resilience.", "experience": "4+ years", "salary": "800,000 FCFA/month"},
                {"title": "Data Analyst", "description": "Analyze research data in {city}. Support academic and corporate studies.", "experience": "3+ years", "salary": "600,000 FCFA/month"},
                {"title": "Field Researcher", "description": "Collect data on biodiversity in {city}. Work with conservation groups.", "experience": "2+ years", "salary": "450,000 FCFA/month"},
                {"title": "Research Coordinator", "description": "Manage research projects in {city}. Ensure timely delivery of results.", "experience": "4+ years", "salary": "700,000 FCFA/month"},
                {"title": "Lab Technician", "description": "Support scientific experiments in {city}. Maintain lab equipment.", "experience": "2+ years", "salary": "400,000 FCFA/month"},
                {"title": "Policy Researcher", "description": "Study public policies in {city}. Provide insights for government projects.", "experience": "3+ years", "salary": "650,000 FCFA/month"},
                {"title": "Market Researcher", "description": "Conduct consumer surveys in {city}. Analyze market trends.", "experience": "3+ years", "salary": "550,000 FCFA/month"},
            ],
            "Immobilier": [
                {"title": "Real Estate Agent", "description": "Facilitate property sales in {city}. Build client relationships.", "experience": "2+ years", "salary": "500,000 FCFA/month"},
                {"title": "Property Manager", "description": "Manage rental properties in {city}. Handle tenant issues and maintenance.", "experience": "3+ years", "salary": "600,000 FCFA/month"},
                {"title": "Real Estate Developer", "description": "Plan housing projects in {city}. Coordinate with contractors.", "experience": "5+ years", "salary": "900,000 FCFA/month"},
                {"title": "Valuation Expert", "description": "Assess property values in {city}. Provide accurate market reports.", "experience": "3+ years", "salary": "650,000 FCFA/month"},
                {"title": "Leasing Consultant", "description": "Assist clients with property leasing in {city}. Negotiate contracts.", "experience": "2+ years", "salary": "450,000 FCFA/month"},
                {"title": "Real Estate Marketing Specialist", "description": "Promote properties in {city}. Create online listings and campaigns.", "experience": "3+ years", "salary": "500,000 FCFA/month"},
                {"title": "Facility Manager", "description": "Oversee maintenance of commercial properties in {city}. Ensure functionality.", "experience": "3+ years", "salary": "550,000 FCFA/month"},
            ],
            "Transport": [
                {"title": "Transport Manager", "description": "Oversee public transport operations in {city}. Ensure schedule adherence.", "experience": "4+ years", "salary": "700,000 FCFA/month"},
                {"title": "Fleet Maintenance Technician", "description": "Repair buses and trucks in {city}. Ensure vehicle reliability.", "experience": "2+ years", "salary": "450,000 FCFA/month"},
                {"title": "Logistics Coordinator", "description": "Plan transport routes in {city}. Optimize delivery schedules.", "experience": "3+ years", "salary": "550,000 FCFA/month"},
                {"title": "Driver Trainer", "description": "Train commercial drivers in {city}. Focus on safety and regulations.", "experience": "3+ years", "salary": "500,000 FCFA/month"},
                {"title": "Traffic Analyst", "description": "Analyze traffic patterns in {city}. Recommend infrastructure improvements.", "experience": "3+ years", "salary": "600,000 FCFA/month"},
                {"title": "Transport Safety Officer", "description": "Ensure safety standards in {city} transport systems. Conduct inspections.", "experience": "3+ years", "salary": "550,000 FCFA/month"},
                {"title": "Courier Service Manager", "description": "Manage delivery services in {city}. Ensure timely parcel delivery.", "experience": "3+ years", "salary": "500,000 FCFA/month"},
            ],
            "Alimentation": [
                {"title": "Food Safety Inspector", "description": "Ensure food quality in {city} restaurants. Conduct hygiene inspections.", "experience": "3+ years", "salary": "550,000 FCFA/month"},
                {"title": "Chef", "description": "Prepare Cameroonian and international dishes in {city} hotels.", "experience": "3+ years", "salary": "500,000 FCFA/month"},
                {"title": "Food Production Manager", "description": "Oversee food processing plants in {city}. Ensure quality control.", "experience": "4+ years", "salary": "700,000 FCFA/month"},
                {"title": "Catering Manager", "description": "Coordinate catering for events in {city}. Manage menus and staff.", "experience": "3+ years", "salary": "550,000 FCFA/month"},
                {"title": "Nutritionist", "description": "Advise clients on diets in {city}. Focus on local food practices.", "experience": "3+ years", "salary": "600,000 FCFA/month"},
                {"title": "Bakery Supervisor", "description": "Manage bakery operations in {city}. Ensure fresh bread production.", "experience": "2+ years", "salary": "450,000 FCFA/month"},
                {"title": "Food Marketing Specialist", "description": "Promote food products in {city}. Develop branding strategies.", "experience": "3+ years", "salary": "500,000 FCFA/month"},
            ],
            "Biotechnologie": [
                {"title": "Biotech Researcher", "description": "Conduct genetic research in {city}. Focus on crop improvement.", "experience": "4+ years", "salary": "800,000 FCFA/month"},
                {"title": "Lab Manager", "description": "Oversee biotech labs in {city}. Ensure compliance with regulations.", "experience": "5+ years", "salary": "900,000 FCFA/month"},
                {"title": "Bioinformatics Specialist", "description": "Analyze biological data in {city}. Develop computational models.", "experience": "3+ years", "salary": "700,000 FCFA/month"},
                {"title": "Biotech Sales Representative", "description": "Promote biotech products in {city}. Target agricultural firms.", "experience": "3+ years", "salary": "550,000 FCFA/month"},
                {"title": "Quality Control Analyst", "description": "Test biotech products in {city}. Ensure safety and efficacy.", "experience": "3+ years", "salary": "600,000 FCFA/month"},
                {"title": "Bioprocess Engineer", "description": "Design bioprocessing systems in {city}. Focus on vaccine production.", "experience": "4+ years", "salary": "850,000 FCFA/month"},
                {"title": "Clinical Research Coordinator", "description": "Manage biotech trials in {city}. Ensure ethical compliance.", "experience": "3+ years", "salary": "650,000 FCFA/month"},
            ],
            "Sécurité": [
                {"title": "Security Manager", "description": "Oversee security operations for businesses in {city}. Develop safety protocols.", "experience": "4+ years", "salary": "700,000 FCFA/month"},
                {"title": "CCTV Operator", "description": "Monitor security cameras in {city}. Report suspicious activities.", "experience": "2+ years", "salary": "400,000 FCFA/month"},
                {"title": "Security Guard", "description": "Protect commercial properties in {city}. Conduct patrols and checks.", "experience": "1+ year", "salary": "300,000 FCFA/month"},
                {"title": "Risk Assessment Specialist", "description": "Evaluate security risks in {city}. Recommend mitigation measures.", "experience": "3+ years", "salary": "550,000 FCFA/month"},
                {"title": "Cybersecurity Consultant", "description": "Protect business IT systems in {city}. Conduct vulnerability assessments.", "experience": "4+ years", "salary": "800,000 FCFA/month"},
                {"title": "Security Trainer", "description": "Train security personnel in {city}. Focus on conflict resolution.", "experience": "3+ years", "salary": "500,000 FCFA/month"},
                {"title": "Access Control Specialist", "description": "Manage entry systems for facilities in {city}. Ensure secure access.", "experience": "2+ years", "salary": "450,000 FCFA/month"},
            ],
            "Design": [
                {"title": "Graphic Designer", "description": "Create visuals for brands in {city}. Design logos and marketing materials.", "experience": "3+ years", "salary": "550,000 FCFA/month"},
                {"title": "UI/UX Designer", "description": "Design user interfaces for apps in {city}. Focus on user experience.", "experience": "3+ years", "salary": "700,000 FCFA/month"},
                {"title": "Interior Designer", "description": "Plan interior spaces for homes in {city}. Create aesthetic layouts.", "experience": "3+ years", "salary": "600,000 FCFA/month"},
                {"title": "Product Designer", "description": "Design consumer products in {city}. Work with manufacturers.", "experience": "4+ years", "salary": "650,000 FCFA/month"},
                {"title": "Motion Graphics Artist", "description": "Create animated content for media in {city}. Use After Effects.", "experience": "3+ years", "salary": "550,000 FCFA/month"},
                {"title": "Design Consultant", "description": "Advise businesses on design strategies in {city}. Enhance brand visuals.", "experience": "4+ years", "salary": "700,000 FCFA/month"},
                {"title": "Packaging Designer", "description": "Design product packaging in {city}. Focus on eco-friendly materials.", "experience": "3+ years", "salary": "500,000 FCFA/month"},
            ],
            "Jeux vidéo": [
                {"title": "Game Developer", "description": "Develop mobile games in {city}. Use Unity for interactive experiences.", "experience": "3+ years", "salary": "800,000 FCFA/month"},
                {"title": "Game Designer", "description": "Create game concepts in {city}. Design levels and mechanics.", "experience": "3+ years", "salary": "700,000 FCFA/month"},
                {"title": "3D Artist", "description": "Model game assets in {city}. Use Blender for character design.", "experience": "3+ years", "salary": "600,000 FCFA/month"},
                {"title": "Game Tester", "description": "Test video games for bugs in {city}. Ensure smooth gameplay.", "experience": "1+ year", "salary": "400,000 FCFA/month"},
                {"title": "Game Marketing Specialist", "description": "Promote games in {city}. Develop online campaigns.", "experience": "3+ years", "salary": "550,000 FCFA/month"},
                {"title": "Narrative Designer", "description": "Write storylines for games in {city}. Create immersive narratives.", "experience": "3+ years", "salary": "600,000 FCFA/month"},
                {"title": "Sound Designer", "description": "Create audio for games in {city}. Design sound effects and music.", "experience": "3+ years", "salary": "550,000 FCFA/month"},
            ],
            "Automobile": [
                {"title": "Automotive Engineer", "description": "Design vehicle components in {city}. Focus on fuel efficiency.", "experience": "4+ years", "salary": "800,000 FCFA/month"},
                {"title": "Mechanic", "description": "Repair vehicles in a {city} garage. Specialize in engine diagnostics.", "experience": "2+ years", "salary": "450,000 FCFA/month"},
                {"title": "Auto Sales Manager", "description": "Manage car dealerships in {city}. Drive sales and customer satisfaction.", "experience": "3+ years", "salary": "600,000 FCFA/month"},
                {"title": "Vehicle Inspector", "description": "Inspect cars for safety in {city}. Ensure compliance with regulations.", "experience": "2+ years", "salary": "500,000 FCFA/month"},
                {"title": "Automotive Designer", "description": "Design car interiors in {city}. Focus on ergonomics and aesthetics.", "experience": "4+ years", "salary": "700,000 FCFA/month"},
                {"title": "Parts Manager", "description": "Manage auto parts inventory in {city}. Ensure timely supply.", "experience": "3+ years", "salary": "550,000 FCFA/month"},
                {"title": "Fleet Manager", "description": "Oversee vehicle fleets for businesses in {city}. Optimize operations.", "experience": "4+ years", "salary": "650,000 FCFA/month"},
            ],
            "Aéronautique": [
                {"title": "Aerospace Engineer", "description": "Design aircraft components in {city}. Focus on safety and efficiency.", "experience": "5+ years", "salary": "1,000,000 FCFA/month"},
                {"title": "Aircraft Mechanic", "description": "Maintain planes in {city} airports. Ensure airworthiness.", "experience": "3+ years", "salary": "600,000 FCFA/month"},
                {"title": "Air Traffic Controller", "description": "Manage air traffic in {city}. Ensure safe takeoffs and landings.", "experience": "4+ years", "salary": "800,000 FCFA/month"},
                {"title": "Aviation Safety Inspector", "description": "Inspect aircraft operations in {city}. Enforce safety regulations.", "experience": "3+ years", "salary": "700,000 FCFA/month"},
                {"title": "Cabin Crew Trainer", "description": "Train flight attendants in {city}. Focus on safety protocols.", "experience": "3+ years", "salary": "550,000 FCFA/month"},
                {"title": "Aerospace Project Manager", "description": "Lead aviation projects in {city}. Coordinate engineering teams.", "experience": "5+ years", "salary": "900,000 FCFA/month"},
                {"title": "Avionics Technician", "description": "Repair aircraft electronics in {city}. Ensure navigation system functionality.", "experience": "3+ years", "salary": "650,000 FCFA/month"},
            ],
            "Environnement": [
                {"title": "Environmental Scientist", "description": "Study ecosystems in {city}. Focus on conservation projects.", "experience": "4+ years", "salary": "700,000 FCFA/month"},
                {"title": "Waste Management Specialist", "description": "Manage recycling programs in {city}. Promote sustainable waste practices.", "experience": "3+ years", "salary": "550,000 FCFA/month"},
                {"title": "Forestry Officer", "description": "Protect forests in {city}. Monitor deforestation activities.", "experience": "3+ years", "salary": "600,000 FCFA/month"},
                {"title": "Environmental Consultant", "description": "Advise businesses in {city} on green practices. Ensure compliance.", "experience": "4+ years", "salary": "650,000 FCFA/month"},
                {"title": "Wildlife Conservationist", "description": "Protect wildlife in {city}. Work with national parks.", "experience": "3+ years", "salary": "550,000 FCFA/month"},
                {"title": "Climate Change Analyst", "description": "Study climate impacts in {city}. Develop adaptation strategies.", "experience": "3+ years", "salary": "600,000 FCFA/month"},
                {"title": "Renewable Energy Consultant", "description": "Promote solar energy adoption in {city}. Advise on green tech.", "experience": "3+ years", "salary": "650,000 FCFA/month"},
            ],
            "Commerce": [
                {"title": "Retail Manager", "description": "Manage stores in {city}. Ensure high sales and customer satisfaction.", "experience": "4+ years", "salary": "650,000 FCFA/month"},
                {"title": "E-commerce Specialist", "description": "Run online stores in {city}. Optimize product listings and sales.", "experience": "3+ years", "salary": "550,000 FCFA/month"},
                {"title": "Sales Associate", "description": "Assist customers in {city} shops. Promote products and services.", "experience": "1+ year", "salary": "300,000 FCFA/month"},
                {"title": "Merchandiser", "description": "Arrange product displays in {city} stores. Enhance visual appeal.", "experience": "2+ years", "salary": "400,000 FCFA/month"},
                {"title": "Procurement Officer", "description": "Source products for businesses in {city}. Negotiate with suppliers.", "experience": "3+ years", "salary": "550,000 FCFA/month"},
                {"title": "Customer Service Manager", "description": "Oversee customer support in {city}. Ensure client satisfaction.", "experience": "3+ years", "salary": "500,000 FCFA/month"},
                {"title": "Market Analyst", "description": "Study market trends in {city}. Guide business strategies.", "experience": "3+ years", "salary": "600,000 FCFA/month"},
            ],
            "Assurance": [
                {"title": "Insurance Agent", "description": "Sell insurance policies in {city}. Focus on health and auto plans.", "experience": "2+ years", "salary": "450,000 FCFA/month"},
                {"title": "Claims Adjuster", "description": "Evaluate insurance claims in {city}. Ensure fair settlements.", "experience": "3+ years", "salary": "550,000 FCFA/month"},
                {"title": "Underwriter", "description": "Assess risks for insurance policies in {city}. Approve applications.", "experience": "3+ years", "salary": "600,000 FCFA/month"},
                {"title": "Insurance Sales Manager", "description": "Lead sales teams for insurance in {city}. Achieve revenue goals.", "experience": "4+ years", "salary": "700,000 FCFA/month"},
                {"title": "Actuary", "description": "Analyze financial risks for insurers in {city}. Use statistical models.", "experience": "4+ years", "salary": "800,000 FCFA/month"},
                {"title": "Customer Service Representative", "description": "Assist policyholders in {city}. Handle inquiries and complaints.", "experience": "1+ year", "salary": "350,000 FCFA/month"},
                {"title": "Risk Manager", "description": "Manage insurance risks in {city}. Develop mitigation strategies.", "experience": "4+ years", "salary": "650,000 FCFA/month"},
            ],
            "Publicité": [
                {"title": "Advertising Manager", "description": "Lead ad campaigns for brands in {city}. Coordinate creative teams.", "experience": "4+ years", "salary": "700,000 FCFA/month"},
                {"title": "Copywriter", "description": "Write ad content for businesses in {city}. Create compelling slogans.", "experience": "2+ years", "salary": "450,000 FCFA/month"},
                {"title": "Media Planner", "description": "Plan ad placements in {city}. Optimize media budgets.", "experience": "3+ years", "salary": "550,000 FCFA/month"},
                {"title": "Creative Director", "description": "Oversee ad visuals and concepts in {city}. Guide creative teams.", "experience": "5+ years", "salary": "800,000 FCFA/month"},
                {"title": "Digital Ad Specialist", "description": "Manage online ads in {city}. Focus on Google and social media ads.", "experience": "3+ years", "salary": "600,000 FCFA/month"},
                {"title": "Market Research Analyst", "description": "Study consumer preferences in {city}. Guide ad strategies.", "experience": "3+ years", "salary": "550,000 FCFA/month"},
                {"title": "Billboard Designer", "description": "Design outdoor ads in {city}. Create eye-catching visuals.", "experience": "2+ years", "salary": "500,000 FCFA/month"},
            ],
            "Événementiel": [
                {"title": "Event Planner", "description": "Organize weddings and corporate events in {city}. Manage logistics.", "experience": "3+ years", "salary": "550,000 FCFA/month"},
                {"title": "Event Coordinator", "description": "Coordinate event details in {city}. Ensure smooth execution.", "experience": "2+ years", "salary": "450,000 FCFA/month"},
                {"title": "Catering Manager", "description": "Manage food services for events in {city}. Ensure quality catering.", "experience": "3+ years", "salary": "500,000 FCFA/month"},
                {"title": "Event Marketing Specialist", "description": "Promote events in {city}. Create buzz through social media.", "experience": "3+ years", "salary": "500,000 FCFA/month"},
                {"title": "Venue Manager", "description": "Oversee event venues in {city}. Ensure facilities are ready.", "experience": "3+ years", "salary": "550,000 FCFA/month"},
                {"title": "Event Decorator", "description": "Design event aesthetics in {city}. Create themed decorations.", "experience": "2+ years", "salary": "400,000 FCFA/month"},
                {"title": "Audio-Visual Technician", "description": "Manage sound and lighting for events in {city}. Ensure technical quality.", "experience": "2+ years", "salary": "450,000 FCFA/month"},
            ],
            "Pharmaceutique": [
                {"title": "Pharmacist", "description": "Dispense medications in {city} pharmacies. Advise on drug use.", "experience": "3+ years", "salary": "700,000 FCFA/month"},
                {"title": "Pharmaceutical Sales Rep", "description": "Promote drugs to clinics in {city}. Build client relationships.", "experience": "2+ years", "salary": "550,000 FCFA/month"},
                {"title": "Quality Control Analyst", "description": "Test drug quality in {city} labs. Ensure regulatory compliance.", "experience": "3+ years", "salary": "600,000 FCFA/month"},
                {"title": "Regulatory Affairs Specialist", "description": "Ensure drug compliance in {city}. Handle regulatory submissions.", "experience": "4+ years", "salary": "750,000 FCFA/month"},
                {"title": "Clinical Researcher", "description": "Conduct drug trials in {city}. Monitor patient outcomes.", "experience": "4+ years", "salary": "800,000 FCFA/month"},
                {"title": "Pharmacy Technician", "description": "Assist pharmacists in {city}. Manage drug inventory.", "experience": "2+ years", "salary": "450,000 FCFA/month"},
                {"title": "Drug Manufacturing Supervisor", "description": "Oversee drug production in {city}. Ensure quality standards.", "experience": "4+ years", "salary": "700,000 FCFA/month"},
            ],
            "Sport": [
                {"title": "Sports Coach", "description": "Train football teams in {city}. Develop player skills and strategies.", "experience": "3+ years", "salary": "500,000 FCFA/month"},
                {"title": "Fitness Trainer", "description": "Lead fitness classes in {city} gyms. Design workout plans.", "experience": "2+ years", "salary": "400,000 FCFA/month"},
                {"title": "Sports Event Organizer", "description": "Plan sports tournaments in {city}. Coordinate teams and venues.", "experience": "3+ years", "salary": "550,000 FCFA/month"},
                {"title": "Physiotherapist", "description": "Treat sports injuries in {city}. Support athlete recovery.", "experience": "3+ years", "salary": "600,000 FCFA/month"},
                {"title": "Sports Marketing Specialist", "description": "Promote sports events in {city}. Create sponsorship campaigns.", "experience": "3+ years", "salary": "500,000 FCFA/month"},
                {"title": "Sports Facility Manager", "description": "Manage stadiums in {city}. Ensure operational efficiency.", "experience": "4+ years", "salary": "650,000 FCFA/month"},
                {"title": "Sports Nutritionist", "description": "Advise athletes on diets in {city}. Optimize performance.", "experience": "3+ years", "salary": "550,000 FCFA/month"},
            ],
        }

        # Create one recruiter per sector
        for sector in job_templates.keys():
            category = Category.objects.get(name=sector)
            # Create recruiter user
            username = f"recruiter_{sector.lower().replace(' ', '_')}"
            email = f"{username}@example.com"
            if not User.objects.filter(username=username).exists():
                user = User.objects.create_user(
                    username=username,
                    email=email,
                    password=password,
                    first_name=f"{sector} Corp",
                    last_name="Recruiter"
                )
                # Create recruiter profile
                RecruiterProfile.objects.create(
                    user=user,
                    company_name=f"{sector} Enterprises",
                    company_description=f"Leading company in {sector} based in Cameroon.",
                    is_validated=True,
                    created_at=timezone.now()
                )
                self.stdout.write(self.style.SUCCESS(f"Created recruiter for {sector}"))
            else:
                user = User.objects.get(username=username)

            # Create 7 job offers for the sector
            for job in job_templates[sector]:
                city = random.choice(cities)
                JobOffer.objects.create(
                    title=job["title"],
                    description=job["description"].format(city=city),
                    category=category,
                    location=city,
                    salary=job["salary"],
                    experience_required=job["experience"],
                    created_by=user,
                    is_validated=True,
                    created_at=timezone.now(),
                    updated_at=timezone.now()
                )
            self.stdout.write(self.style.SUCCESS(f"Created 7 job offers for {sector}"))