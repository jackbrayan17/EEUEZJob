from django.shortcuts import render, redirect, get_object_or_404
from django.http import JsonResponse
from django.contrib.auth.decorators import login_required
from django.views.decorators.csrf import csrf_exempt
from django.contrib import messages
from django.utils import timezone
from django.contrib.auth.forms import UserCreationForm
import requests
import json
from .models import JobOffer, Message, CandidateProfile, Testimonial, Category, RecruiterProfile
from .forms import CandidateProfileForm, TestimonialForm, RecruiterProfileForm, JobOfferForm
from django.conf import settings

def get_common_context():
    """Return common context with categorized job offers."""
    categories = Category.objects.all()
    return {
        'grouped_jobs': [(category, JobOffer.objects.filter(category=category, is_validated=True)[:5]) for category in categories],
        'categories': categories
    }

def home(request):
    """Render the homepage."""
    return render(request, 'core/index.html', get_common_context())

def signup(request):
    """Handle user registration."""
    if request.method == 'POST':
        form = UserCreationForm(request.POST)
        if form.is_valid():
            form.save()
            messages.success(request, "Inscription réussie ! Veuillez vous connecter.")
            return redirect('account_login')
        messages.error(request, f"Erreur dans le formulaire : {form.errors}")
    else:
        form = UserCreationForm()
    return render(request, 'account/signup.html', {'form': form, **get_common_context()})

@login_required
def profile_create(request, profile_type='candidate'):
    """Create a candidate or recruiter profile."""
    profile_map = {
        'candidate': (CandidateProfile, CandidateProfileForm, 'candidate_profile', 'recruiter_profile', 'core/candidate_profile_form.html'),
        'recruiter': (RecruiterProfile, RecruiterProfileForm, 'recruiter_profile', 'candidate_profile', 'core/recruiter_profile_form.html')
    }
    model, form_class, profile_attr, other_profile_attr, template = profile_map[profile_type]

    if hasattr(request.user, profile_attr) and hasattr(request.user, other_profile_attr):
        messages.error(request, "Vous ne pouvez avoir qu'un seul type de profil.")
        return redirect('home')
    if hasattr(request.user, other_profile_attr):
        messages.error(request, f"Vous avez déjà un profil {other_profile_attr.replace('_profile', '')}. Vous ne pouvez pas créer un profil {profile_attr.replace('_profile', '')}.")
        return redirect('home')

    if request.method == 'POST':
        form = form_class(request.POST, request.FILES)
        if form.is_valid():
            profile = form.save(commit=False)
            profile.user = request.user
            profile.save()
            form.save_m2m()
            messages.success(request, f"Profil {profile_type} créé avec succès !")
            return redirect('profile')
        messages.error(request, f"Erreur dans le formulaire : {form.errors}")
    else:
        form = form_class()
    return render(request, template, {'form': form, **get_common_context()})

@login_required
def profile_edit(request, profile_type='candidate'):
    """Edit an existing candidate or recruiter profile."""
    profile_map = {
        'candidate': (CandidateProfile, CandidateProfileForm, 'core/candidate_profile_form.html'),
        'recruiter': (RecruiterProfile, RecruiterProfileForm, 'core/recruiter_profile_form.html')
    }
    model, form_class, template = profile_map[profile_type]
    profile = get_object_or_404(model, user=request.user)

    if request.method == 'POST':
        form = form_class(request.POST, request.FILES, instance=profile)
        if form.is_valid():
            form.save()
            messages.success(request, f"Profil {profile_type} mis à jour avec succès !")
            return redirect('profile')
        messages.error(request, f"Erreur dans le formulaire : {form.errors}")
    else:
        form = form_class(instance=profile)
    return render(request, template, {'form': form, **get_common_context()})

@login_required
def profile_delete(request):
    """Delete a user's candidate or recruiter profile."""
    has_candidate = hasattr(request.user, 'candidate_profile')
    has_recruiter = hasattr(request.user, 'recruiter_profile')

    if not (has_candidate or has_recruiter):
        messages.error(request, "Vous n'avez aucun profil à supprimer.")
        return redirect('home')

    if request.method == 'POST':
        profile_type = 'candidat' if has_candidate else 'recruteur'
        getattr(request.user, 'candidate_profile' if has_candidate else 'recruiter_profile').delete()
        messages.success(request, f"Votre profil {profile_type} a été supprimé avec succès.")
        return redirect('home')

    return render(request, 'core/profile_delete_confirm.html', {
        'has_candidate_profile': has_candidate,
        'has_recruiter_profile': has_recruiter,
        **get_common_context()
    })

@csrf_exempt
@login_required
def ai_chatbot(request):
    """Handle AI chatbot interactions."""
    if request.method != 'POST':
        return render(request, 'core/ai_chatbot.html', get_common_context())

    try:
        data = json.loads(request.body)
        user_message = data.get('message', '')
    except json.JSONDecodeError:
        return JsonResponse({'response': 'Erreur : Format de données invalide.'}, status=400)

    profile = getattr(request.user, 'candidate_profile', None)
    if not profile:
        return JsonResponse({'response': 'Veuillez créer votre profil candidat d’abord.'}, status=403)

    headers = {'Authorization': f'Bearer {settings.API_KEY}', 'Content-Type': 'application/json'}
    payload = {
        'model': 'grok-3',
        'messages': [
            {
                'role': 'system',
                'content': (
                    'Vous êtes une IA conçue uniquement pour guider l’utilisateur dans l’application EEUEZJob. '
                    'Répondez uniquement aux questions liées à la création de profil, à l’amélioration du CV, '
                    'à la recherche d’offres d’emploi, ou à l’utilisation de l’application. '
                    'Ignorez toute question hors sujet. Si l’utilisateur demande une amélioration de CV, '
                    'proposez des suggestions basées sur ses compétences, formations, années d’expérience '
                    'et secteurs d’activité, et incluez un exemple de texte à intégrer.'
                )
            },
            {
                'role': 'user',
                'content': (
                    f'Profil: {profile.full_name}, Compétences: {profile.skills}, '
                    f'Expérience: {profile.years_experience} ans, Éducation: {profile.education}, '
                    f'Secteurs: {[c.name for c in profile.sectors.all()]}. Question: {user_message}'
                )
            }
        ]
    }

    try:
        response = requests.post('https://api.xai.com/v1/chat', headers=headers, data=json.dumps(payload))
        response.raise_for_status()
        ai_response = response.json().get('choices', [{}])[0].get('message', {}).get('content', 'Désolé, je n’ai pas compris.')
        return JsonResponse({'response': ai_response})
    except requests.RequestException:
        return JsonResponse({'response': 'Erreur lors de la communication avec l’IA.'}, status=500)

@login_required
def job_offer_list(request):
    """Display job offers with AI-driven sorting if profile exists."""
    job_offers = JobOffer.objects.filter(is_validated=True)
    profile = getattr(request.user, 'candidate_profile', None)

    if profile:
        headers = {'Authorization': f'Bearer {settings.API_KEY}', 'Content-Type': 'application/json'}
        payload = {
            'model': 'grok-3',
            'messages': [
                {
                    'role': 'system',
                    'content': (
                        'Vous êtes une IA pour EEUEZJob. Classez les offres d’emploi par pertinence '
                        'pour un profil donné (compétences, expérience, secteurs). '
                        'Retournez une liste d’IDs d’offres triées, séparés par des virgules.'
                    )
                },
                {
                    'role': 'user',
                    'content': (
                        f'Profil: Compétences: {profile.skills}, Expérience: {profile.years_experience} ans, '
                        f'Secteurs: {[c.name for c in profile.sectors.all()]}. Offres: {[o.id for o in job_offers]}'
                    )
                }
            ]
        }
        try:
            response = requests.post('https://api.xai.com/v1/chat', headers=headers, data=json.dumps(payload))
            response.raise_for_status()
            ranked_ids = [int(id.strip()) for id in response.json().get('choices', [{}])[0].get('message', {}).get('content', '').split(',') if id.strip().isdigit()]
            job_offers = sorted(job_offers, key=lambda x: ranked_ids.index(x.id) if x.id in ranked_ids else len(ranked_ids))
        except (requests.RequestException, ValueError):
            pass

    context = get_common_context()
    context['job_offers'] = job_offers
    context['other_offers'] = job_offers[len(job_offers) // 2:] if profile and len(job_offers) > 6 else []
    return render(request, 'core/job_offer_list.html', context)

@login_required
def job_offer_detail(request, pk):
    """Display details of a specific job offer."""
    job_offer = get_object_or_404(JobOffer, pk=pk, is_validated=True)
    return render(request, 'core/job_offer_detail.html', {'job_offer': job_offer, **get_common_context()})

@login_required
def job_offer_edit(request, pk):
    """Edit an existing job offer."""
    job_offer = get_object_or_404(JobOffer, pk=pk, created_by=request.user)
    if request.method == 'POST':
        form = JobOfferForm(request.POST, instance=job_offer)
        if form.is_valid():
            form.save()
            messages.success(request, 'Offre d’emploi mise à jour avec succès !')
            return redirect('profile')
        messages.error(request, f'Erreur dans le formulaire : {form.errors}')
    else:
        form = JobOfferForm(instance=job_offer)
    return render(request, 'core/job_offer_form.html', {'form': form, **get_common_context()})

@login_required
def message_list(request):
    """Display a list of messages received by the user."""
    return render(request, 'core/message_list.html', {
        'messages': Message.objects.filter(recipient=request.user).order_by('-created_at'),
        **get_common_context()
    })

@login_required
def submit_testimonial(request):
    """Handle testimonial submission."""
    if request.method == 'POST':
        form = TestimonialForm(request.POST)
        if form.is_valid():
            Testimonial.objects.create(
                user=request.user,
                content=form.cleaned_data['content'],
                created_at=timezone.now()
            )
            messages.success(request, 'Témoignage soumis avec succès !')
            return redirect('home')
        messages.error(request, f'Erreur dans le formulaire : {form.errors}')
    else:
        form = TestimonialForm()
    return render(request, 'core/submit_testimonial.html', {'form': form, **get_common_context()})

@login_required
def profile(request):
    """Display the logged-in user's profile."""
    return render(request, 'account/profile.html', get_common_context())