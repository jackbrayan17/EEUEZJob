from django import forms
from django.core.exceptions import ValidationError
from crispy_forms.helper import FormHelper
from crispy_forms.layout import Submit
from .models import CandidateProfile, RecruiterProfile, Testimonial, JobOffer, Category
import json

class CandidateProfileForm(forms.ModelForm):
    social_links = forms.CharField(
        widget=forms.TextInput(attrs={
            'id': 'socialLinks',
            'class': 'form-input w-full p-2 border rounded bg-gray-700 text-white border-gray-600 focus:ring-2 focus:ring-orange-500',
            'placeholder': 'Ex: {"LinkedIn": "https://linkedin.com/in/votre-profil", "GitHub": "https://github.com/votre-profil"}'
        }),
        required=False,
        label="Liens sociaux (JSON)"
    )

    class Meta:
        model = CandidateProfile
        fields = ['full_name', 'skills', 'years_experience', 'education', 'cv_file', 'profile_picture', 'social_links', 'sectors']
        widgets = {
            'full_name': forms.TextInput(attrs={
                'id': 'fullName',
                'class': 'form-input w-full p-2 border rounded bg-gray-700 text-white border-gray-600 focus:ring-2 focus:ring-orange-500',
                'placeholder': 'Entrez votre nom complet'
            }),
            'skills': forms.TextInput(attrs={
                'id': 'skills',
                'class': 'form-input w-full p-2 border rounded bg-gray-700 text-white border-gray-600 focus:ring-2 focus:ring-orange-500',
                'placeholder': 'Ex: Python, Gestion de projet'
            }),
            'years_experience': forms.NumberInput(attrs={
                'id': 'experience',
                'class': 'form-input w-full p-2 border rounded bg-gray-700 text-white border-gray-600 focus:ring-2 focus:ring-orange-500',
                'placeholder': 'Ex: 5',
                'min': 0
            }),
            'education': forms.TextInput(attrs={
                'id': 'education',
                'class': 'form-input w-full p-2 border rounded bg-gray-700 text-white border-gray-600 focus:ring-2 focus:ring-orange-500',
                'placeholder': 'Ex: Master en Informatique'
            }),
            'profile_picture': forms.FileInput(attrs={
                'id': 'profilePicture',
                'class': 'form-input w-full p-2 border rounded bg-gray-700 text-white border-gray-600 focus:ring-2 focus:ring-orange-500',
                'accept': 'image/jpeg,image/png'
            }),
            'cv_file': forms.FileInput(attrs={
                'id': 'cvFile',
                'class': 'form-input w-full p-2 border rounded bg-gray-700 text-white border-gray-600 focus:ring-2 focus:ring-orange-500',
                'accept': 'application/pdf,application/msword,application/vnd.openxmlformats-officedocument.wordprocessingml.document'
            }),
            'sectors': forms.ModelMultipleChoiceField(
                queryset=Category.objects.all(),
                widget=forms.CheckboxSelectMultiple(attrs={
                    'class': 'form-checkbox text-orange-500'
                }),
                required=False
            )
        }

    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)
        self.helper = FormHelper()
        self.helper.form_method = 'post'
        self.helper.form_enctype = 'multipart/form-data'  # Required for file uploads
        self.helper.add_input(Submit('submit', 'Enregistrer', css_class='bg-orange-500 text-white px-4 py-2 rounded hover:bg-orange-600 w-full'))

        # Pre-populate social_links with JSON if editing
        if self.instance and self.instance.social_links:
            self.fields['social_links'].initial = json.dumps(self.instance.social_links)

    def clean_social_links(self):
        social_links = self.cleaned_data.get('social_links')
        if social_links:
            try:
                json.loads(social_links)
            except json.JSONDecodeError:
                raise ValidationError("Les liens sociaux doivent être au format JSON valide, ex: {\"LinkedIn\": \"https://linkedin.com/in/votre-profil\"}")
        return social_links

    def clean_cv_file(self):
        cv_file = self.cleaned_data.get('cv_file')
        if cv_file:
            if cv_file.size > 5 * 1024 * 1024:  # 5MB limit
                raise ValidationError("Le fichier CV ne doit pas dépasser 5 Mo.")
        return cv_file

    def clean_profile_picture(self):
        profile_picture = self.cleaned_data.get('profile_picture')
        if profile_picture:
            if profile_picture.size > 2 * 1024 * 1024:  # 2MB limit
                raise ValidationError("La photo de profil ne doit pas dépasser 2 Mo.")
        return profile_picture

    def save(self, commit=True):
        instance = super().save(commit=False)
        social_links = self.cleaned_data.get('social_links')
        if social_links:
            instance.social_links = json.loads(social_links)
        else:
            instance.social_links = {}
        if commit:
            instance.save()
            self.save_m2m()  # Save many-to-many fields (sectors)
        return instance

class TestimonialForm(forms.ModelForm):
    class Meta:
        model = Testimonial
        fields = ['content']
        widgets = {
            'content': forms.Textarea(attrs={
                'id': 'review',
                'class': 'form-input w-full p-2 border rounded bg-gray-700 text-white border-gray-600 focus:ring-2 focus:ring-orange-500',
                'placeholder': 'Entrez votre témoignage...',
                'rows': 4
            })
        }
        labels = {
            'content': 'Votre témoignage'
        }

    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)
        self.helper = FormHelper()
        self.helper.form_method = 'post'
        self.helper.add_input(Submit('submit', 'Soumettre', css_class='bg-orange-500 text-white px-4 py-2 rounded hover:bg-orange-600 w-full'))

class RecruiterProfileForm(forms.ModelForm):
    company_website = forms.URLField(
        required=False,
        widget=forms.URLInput(attrs={
            'id': 'companyWebsite',
            'class': 'form-input w-full p-2 border rounded bg-gray-700 text-white border-gray-600 focus:ring-2 focus:ring-orange-500',
            'placeholder': 'Ex: https://www.votre-entreprise.com'
        }),
        label="Site web de l'entreprise"
    )
    company_address = forms.CharField(
        max_length=200,
        required=True,
        widget=forms.TextInput(attrs={
            'id': 'companyAddress',
            'class': 'form-input w-full p-2 border rounded bg-gray-700 text-white border-gray-600 focus:ring-2 focus:ring-orange-500',
            'placeholder': 'Entrez l’adresse de l’entreprise'
        }),
        label="Adresse de l'entreprise"
    )
    recruiter_name = forms.CharField(
        max_length=200,
        required=True,
        widget=forms.TextInput(attrs={
            'id': 'recruiterName',
            'class': 'form-input w-full p-2 border rounded bg-gray-700 text-white border-gray-600 focus:ring-2 focus:ring-orange-500',
            'placeholder': 'Entrez votre nom complet'
        }),
        label="Nom complet"
    )
    recruiter_position = forms.CharField(
        max_length=200,
        required=True,
        widget=forms.TextInput(attrs={
            'id': 'recruiterPosition',
            'class': 'form-input w-full p-2 border rounded bg-gray-700 text-white border-gray-600 focus:ring-2 focus:ring-orange-500',
            'placeholder': 'Ex: Responsable RH'
        }),
        label="Poste/Fonction"
    )
    recruiter_email = forms.EmailField(
        required=True,
        widget=forms.EmailInput(attrs={
            'id': 'recruiterEmail',
            'class': 'form-input w-full p-2 border rounded bg-gray-700 text-white border-gray-600 focus:ring-2 focus:ring-orange-500',
            'placeholder': 'Entrez votre email professionnel'
        }),
        label="Email professionnel"
    )
    recruiter_phone = forms.CharField(
        max_length=20,
        required=False,
        widget=forms.TextInput(attrs={
            'id': 'recruiterPhone',
            'class': 'form-input w-full p-2 border rounded bg-gray-700 text-white border-gray-600 focus:ring-2 focus:ring-orange-500',
            'placeholder': 'Ex: +237 123 456 789'
        }),
        label="Téléphone professionnel"
    )
    linkedin_profile = forms.URLField(
        required=False,
        widget=forms.URLInput(attrs={
            'id': 'linkedinProfile',
            'class': 'form-input w-full p-2 border rounded bg-gray-700 text-white border-gray-600 focus:ring-2 focus:ring-orange-500',
            'placeholder': 'Ex: https://linkedin.com/in/votre-profil'
        }),
        label="Profil LinkedIn"
    )
    company_description = forms.CharField(
        widget=forms.Textarea(attrs={
            'id': 'companyDescription',
            'class': 'form-input w-full p-2 border rounded bg-gray-700 text-white border-gray-600 focus:ring-2 focus:ring-orange-500',
            'rows': 4,
            'placeholder': 'Décrivez votre entreprise'
        }),
        required=True,
        label="Description de l'entreprise"
    )
    company_size = forms.ChoiceField(
        choices=[
            ('Startup (1-10 employés)', 'Startup (1-10 employés)'),
            ('Petite entreprise (11-50 employés)', 'Petite entreprise (11-50 employés)'),
            ('Moyenne entreprise (51-250 employés)', 'Moyenne entreprise (51-250 employés)'),
            ('Grande entreprise (251-1000 employés)', 'Grande entreprise (251-1000 employés)'),
            ('Très grande entreprise (1000+ employés)', 'Très grande entreprise (1000+ employés)')
        ],
        widget=forms.Select(attrs={
            'id': 'companySize',
            'class': 'form-input w-full p-2 border rounded bg-gray-700 text-white border-gray-600 focus:ring-2 focus:ring-orange-500'
        }),
        required=True,
        label="Taille de l'entreprise"
    )
    recruitment_areas = forms.CharField(
        max_length=200,
        required=False,
        widget=forms.TextInput(attrs={
            'id': 'recruitmentAreas',
            'class': 'form-input w-full p-2 border rounded bg-gray-700 text-white border-gray-600 focus:ring-2 focus:ring-orange-500',
            'placeholder': 'Ex: Douala, Yaoundé'
        }),
        label="Zones géographiques de recrutement"
    )
    welcome_message = forms.CharField(
        widget=forms.Textarea(attrs={
            'id': 'welcomeMessage',
            'class': 'form-input w-full p-2 border rounded bg-gray-700 text-white border-gray-600 focus:ring-2 focus:ring-orange-500',
            'rows': 4,
            'placeholder': 'Message d’accueil pour les candidats'
        }),
        required=False,
        label="Message d'accueil pour les candidats"
    )
    sectors = forms.ModelMultipleChoiceField(
        queryset=Category.objects.all(),
        widget=forms.CheckboxSelectMultiple(attrs={
            'id': 'sectors',
            'class': 'form-checkbox text-orange-500'
        }),
        required=False,
        label="Secteurs d'activité"
    )

    class Meta:
        model = RecruiterProfile
        fields = ['company_name', 'company_description', 'sectors']
        widgets = {
            'company_name': forms.TextInput(attrs={
                'id': 'companyName',
                'class': 'form-input w-full p-2 border rounded bg-gray-700 text-white border-gray-600 focus:ring-2 focus:ring-orange-500',
                'placeholder': 'Entrez le nom de l’entreprise'
            })
        }

    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)
        self.helper = FormHelper()
        self.helper.form_method = 'post'
        self.helper.form_enctype = 'multipart/form-data'  # Required for file uploads
        self.helper.add_input(Submit('submit', 'Enregistrer', css_class='bg-orange-500 text-white px-4 py-2 rounded hover:bg-orange-600 w-full'))

    def save(self, commit=True):
        instance = super().save(commit=False)
        instance.company_website = self.cleaned_data.get('company_website')
        instance.company_address = self.cleaned_data.get('company_address')
        instance.recruiter_name = self.cleaned_data.get('recruiter_name')
        instance.recruiter_position = self.cleaned_data.get('recruiter_position')
        instance.recruiter_email = self.cleaned_data.get('recruiter_email')
        instance.recruiter_phone = self.cleaned_data.get('recruiter_phone')
        instance.linkedin_profile = self.cleaned_data.get('linkedin_profile')
        instance.company_size = self.cleaned_data.get('company_size')
        instance.recruitment_areas = self.cleaned_data.get('recruitment_areas')
        instance.welcome_message = self.cleaned_data.get('welcome_message')
        if commit:
            instance.save()
            self.save_m2m()  # Save many-to-many fields (sectors)
        return instance

class JobOfferForm(forms.ModelForm):
    class Meta:
        model = JobOffer
        fields = ['title', 'description', 'category', 'location', 'salary', 'experience_required']
        widgets = {
            'title': forms.TextInput(attrs={
                'id': 'title',
                'class': 'form-input w-full p-2 border rounded bg-gray-700 text-white border-gray-600 focus:ring-2 focus:ring-orange-500',
                'placeholder': 'Entrez le titre de l’offre'
            }),
            'description': forms.Textarea(attrs={
                'id': 'description',
                'class': 'form-input w-full p-2 border rounded bg-gray-700 text-white border-gray-600 focus:ring-2 focus:ring-orange-500',
                'rows': 6,
                'placeholder': 'Décrivez l’offre d’emploi'
            }),
            'category': forms.Select(attrs={
                'id': 'category',
                'class': 'form-input w-full p-2 border rounded bg-gray-700 text-white border-gray-600 focus:ring-2 focus:ring-orange-500'
            }),
            'location': forms.TextInput(attrs={
                'id': 'location',
                'class': 'form-input w-full p-2 border rounded bg-gray-700 text-white border-gray-600 focus:ring-2 focus:ring-orange-500',
                'placeholder': 'Ex: Douala'
            }),
            'salary': forms.TextInput(attrs={
                'id': 'salary',
                'class': 'form-input w-full p-2 border rounded bg-gray-700 text-white border-gray-600 focus:ring-2 focus:ring-orange-500',
                'placeholder': 'Ex: 500,000 FCFA/month'
            }),
            'experience_required': forms.TextInput(attrs={
                'id': 'experienceRequired',
                'class': 'form-input w-full p-2 border rounded bg-gray-700 text-white border-gray-600 focus:ring-2 focus:ring-orange-500',
                'placeholder': 'Ex: 3+ years'
            })
        }

    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)
        self.helper = FormHelper()
        self.helper.form_method = 'post'
        self.helper.add_input(Submit('submit', 'Enregistrer', css_class='bg-orange-500 text-white px-4 py-2 rounded hover:bg-orange-600 w-full'))