from django.urls import path
from django.contrib.auth import views as auth_views
from django.conf import settings
from django.conf.urls.static import static
from core import views

urlpatterns = [
    path('', views.home, name='home'),
    path('profile/candidate/create/', views.profile_create, {'profile_type': 'candidate'}, name='candidate_profile_create'),
    path('profile/candidate/edit/', views.profile_edit, {'profile_type': 'candidate'}, name='candidate_profile_edit'),
    path('profile/recruiter/create/', views.profile_create, {'profile_type': 'recruiter'}, name='recruiter_profile_create'),
    path('profile/recruiter/edit/', views.profile_edit, {'profile_type': 'recruiter'}, name='recruiter_profile_edit'),
    path('profile/delete/', views.profile_delete, name='profile_delete'),
    path('jobs/', views.job_offer_list, name='job_offer_list'),
    path('jobs/<int:pk>/', views.job_offer_detail, name='job_offer_detail'),
    path('jobs/<int:pk>/edit/', views.job_offer_edit, name='job_offer_edit'),
    path('messages/', views.message_list, name='message_list'),
    path('testimonial/', views.submit_testimonial, name='submit_testimonial'),
    path('profile/', views.profile, name='profile'),
    path('chatbot/', views.ai_chatbot, name='chatbot'),
    path('accounts/login/', auth_views.LoginView.as_view(template_name='account/login.html'), name='account_login'),
    path('accounts/logout/', auth_views.LogoutView.as_view(next_page='home'), name='account_logout'),
    path('accounts/signup/', views.signup, name='account_signup'),
] + static(settings.MEDIA_URL, document_root=settings.MEDIA_ROOT)